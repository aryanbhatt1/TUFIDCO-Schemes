module.exports = window.django.jQuery;
