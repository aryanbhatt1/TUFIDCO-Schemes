from django.apps import AppConfig


class TufidcoappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TUFIDCOapp'
    verbose_name = 'TUFIDCO Forms'
