from django.apps import AppConfig


class UlbformsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ULBForms'
    verbose_name = 'ULB Forms'
