from django.apps import AppConfig


class ErrorreportsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Errorreports'
    verbose_name= 'Error Reports'
