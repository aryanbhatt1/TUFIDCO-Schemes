from django.apps import AppConfig


class CtpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CTP'
    verbose_name = 'Town Panchayats'
