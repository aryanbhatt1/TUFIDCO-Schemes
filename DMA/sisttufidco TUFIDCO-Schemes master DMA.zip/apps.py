from django.apps import AppConfig


class DmaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DMA'
    verbose_name = 'Municipalities'
